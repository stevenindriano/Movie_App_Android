NOTE:
API IMDB tersebut adalah API FREEMIUM,
apabila list tidak dapat diload artinya request pada API tersebut
sudah melebihi limit per bulannya. (100 req/month)